import { GoogleGenAI } from "@google/genai";

let ai: GoogleGenAI | null = null;
try {
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
} catch (error) {
    console.error("Failed to initialize GoogleGenAI:", error);
}


const codeEditor = document.getElementById('codeEditor') as HTMLTextAreaElement;
const previewFrame = document.getElementById('previewFrame') as HTMLIFrameElement;
const runCodeBtn = document.getElementById('runCodeBtn') as HTMLButtonElement;
const aiPromptInput = document.getElementById('aiPromptInput') as HTMLInputElement;
const generateCodeBtn = document.getElementById('generateCodeBtn') as HTMLButtonElement;
const terminalOutput = document.getElementById('terminalOutput') as HTMLDivElement;
const loadingSpinner = document.getElementById('loadingSpinner') as HTMLElement;
const generateBtnText = document.getElementById('generateBtnText') as HTMLSpanElement;
const copyCodeBtn = document.getElementById('copyCodeBtn') as HTMLButtonElement;

// Function to append messages to the terminal output
function appendTerminalOutput(message: string, className = 'text-gray-200') {
    const p = document.createElement('p');
    p.textContent = message;
    p.className = className + ' mb-1'; // Add margin-bottom for spacing
    terminalOutput.appendChild(p);
    terminalOutput.scrollTop = terminalOutput.scrollHeight; // Scroll to bottom
}

if (!process.env.API_KEY || !ai) {
    appendTerminalOutput("Chyba: API kľúč pre Gemini nebol nájdený. Generovanie kódu je vypnuté.", "text-red-400");
    if(generateCodeBtn) generateCodeBtn.disabled = true;
}


// Function to update the preview iframe
function updatePreview() {
    if (codeEditor && previewFrame) {
        const code = codeEditor.value;
        previewFrame.srcdoc = code;
    }
}

// Initial preview update on load
window.onload = () => {
    updatePreview();
};

// Event listener for the "Run Code" button
runCodeBtn?.addEventListener('click', updatePreview);

// Event listener for the "Generate Code" button (AI interaction)
generateCodeBtn?.addEventListener('click', async () => {
    if (!ai) {
        appendTerminalOutput("AI klient nie je inicializovaný.", 'text-red-400');
        return;
    }
    const prompt = aiPromptInput.value.trim();
    if (!prompt) {
        appendTerminalOutput("Prosím, zadajte príkaz pre AI.", 'text-yellow-400');
        return;
    }

    // Show loading state
    generateCodeBtn.disabled = true;
    generateBtnText.textContent = 'Generujem...';
    loadingSpinner.classList.remove('hidden');
    appendTerminalOutput(`Používateľ: ${prompt}`);

    try {
        const currentCode = codeEditor.value;
        const llmPrompt = `Ste profesionálny AI App Builder. Vašou úlohou je generovať kompletné, spustiteľné HTML súbory (vrátane CSS v <style> a JavaScriptu v <script>).
Používateľ požaduje: "${prompt}".
Aktuálny kód pre kontext (ak je k dispozícii pre úpravy):
\`\`\`html
${currentCode}
\`\`\`
Prosím, vygenerujte kompletný HTML kód, ktorý spĺňa požiadavku používateľa. Ak ide o úpravu, integrujte zmeny do existujúceho kódu.
Dôležité: Nepoužívajte funkcie alert() alebo confirm(). Namiesto toho použite vlastné modálne okná alebo správy v DOM.
Odpovedajte iba s blokom kódu v markdown formáte (napr. \`\`\`html ... \`\`\`).`;
        
        appendTerminalOutput("AI: Generujem kód...", 'text-blue-400');

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: llmPrompt,
        });

        const generatedText = response.text;

        // Extract the HTML code block
        const htmlMatch = generatedText.match(/```(?:html)?\n([\s\S]*?)\n```/);
        let extractedCode = '';
        if (htmlMatch && htmlMatch[1]) {
            extractedCode = htmlMatch[1];
            appendTerminalOutput("AI: Kód bol úspešne vygenerovaný a aktualizovaný v editore.", 'text-green-400');
        } else {
            extractedCode = generatedText;
            appendTerminalOutput("AI: Kód bol vygenerovaný, ale nebol nájdený v očakávanom formáte. Celá odpoveď AI bola vložená do editora.", 'text-orange-400');
        }

        codeEditor.value = extractedCode;
        updatePreview();
    } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        appendTerminalOutput(`AI: Vyskytla sa chyba pri generovaní kódu: ${errorMessage}`, 'text-red-400');
        console.error("AI generation error:", error);
    } finally {
        // Hide loading state
        generateCodeBtn.disabled = false;
        generateBtnText.textContent = 'Generovať';
        loadingSpinner.classList.add('hidden');
        aiPromptInput.value = ''; // Clear input
    }
});

// Event listener for the "Copy Code" button
copyCodeBtn?.addEventListener('click', () => {
    const codeToCopy = codeEditor.value;
    navigator.clipboard.writeText(codeToCopy).then(() => {
        appendTerminalOutput("Kód bol skopírovaný do schránky!", 'text-green-400');
    }).catch(err => {
        appendTerminalOutput("Nepodarilo sa skopírovať kód. Prosím, skopírujte ho manuálne.", 'text-red-400');
        console.error('Failed to copy code:', err);
    });
});

// Ensure initial preview is loaded
updatePreview();
